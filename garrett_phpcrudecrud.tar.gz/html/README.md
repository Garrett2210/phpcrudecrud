# INET4031 PHP Crude CRUD App (MariaDB/MySQL DB Version)

## Demonstrates a basic Dynamic HTML Application using PHP

It doesn't get much more crude than this, but is a great starting point for understanding how **dynamic data-driven web applications** work.

Understand how this one works, and more modern/advanced/complex web development frameworks, won't seem so mysterious.

This application assumes the MySQL database has certain users added and an "employees" database based on a sample dataset. Additional details will be provided in class.

The "credentials.php" file above has the details of the MySQL database connection.  You will need to modify this file to work for your configuration

Obviously everything is in the open and unsecure here.

...and obviously change the credentials too...
