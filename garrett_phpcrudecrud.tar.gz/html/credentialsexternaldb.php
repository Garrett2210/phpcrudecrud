<?php
$servername = '192.168.56.101';     //if apache on diff server from db or using Docker, set IP address
$dbname = 'employees';          //which db you're going to use
$username = 'phpuser1';
$password = 'abc123';
?>
