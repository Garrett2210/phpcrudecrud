<?php                            //connection & credentials
$servername = "localhost";      //mysql is on the same host as apache
$dbname = "employees";          //which db you're going to use
$username = "phpuser1";
$password = "abc123";
?>
