<html>
	<head>
	</head>
	<body>
		Hello World
		<?php
		phpinfo()
		?>
	</body>
</html>
